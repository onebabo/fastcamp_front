export function add(a, b) { 
  return a + b
}

export function sub(a, b) { 
  return a - b 
}

export function multi(a, b) { 
  return a * b
}

export function div(a, b) { 
  return a / b
}
