

export const AppleName = '대구 사과'
export const CarName = '그랜저'

export function Sum(a, b, c) {
  return a + b + c
}
